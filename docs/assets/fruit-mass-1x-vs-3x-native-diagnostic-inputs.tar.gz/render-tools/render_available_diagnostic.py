#!/usr/bin/env python3
"""Render the completed first 120 frames available on two Apple hosts."""

import csv
import hashlib
import json
import math
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path('/Users/home/numi-solver-contact-reset-20260929/build/native-pickup-contact-reset-20260929')
HEAVY = HERE / 'quick-record/triple-fruit-pickup-120-20260929'
AUDIT = pathlib.Path('/Users/home/numi-solver/build/native-contact-reset-independent-audit-20260929')
sys.path.insert(0, str(AUDIT))
import snapshot_geometry as geometry

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1 << 20), b''):
            h.update(part)
    return h.hexdigest()

def fruit_states(path):
    with path.open(newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) >= 121 * 12
    states = {}
    for row in rows[:121 * 12]:
        frame, fruit = int(row['frame']), int(row['fruit'])
        assert int(row['replay']) == 1 and (frame, fruit) not in states
        assert math.isclose(float(row['time_s']), frame / 120, abs_tol=1e-6)
        states[frame, fruit] = row
    assert set(states) == {(f, i) for f in range(121) for i in range(12)}
    return states

def main():
    video = HERE / 'fruit-mass-1x-vs-3x-native-diagnostic.mp4'
    poster = HERE / 'fruit-mass-1x-vs-3x-native-diagnostic.png'
    receipt = HERE / 'fruit-mass-1x-vs-3x-native-diagnostic.json'
    assert not any(path.exists() for path in (video, poster, receipt))
    edges, faces, local = geometry.topology()
    first_obj = [pathlib.Path(str(prefix) + '-0.obj') for prefix in (BASE, HEAVY)]
    assert first_obj[0].read_bytes() == first_obj[1].read_bytes()
    base_fruit = fruit_states(pathlib.Path(str(BASE) + '-r1-fruits.csv'))
    heavy_fruit = fruit_states(pathlib.Path(str(HEAVY) + '-r1-fruits.csv'))
    for fruit in range(12):
        for key in ('x_m', 'y_m', 'z_m', 'radius_m'):
            assert base_fruit[0, fruit][key] == heavy_fruit[0, fruit][key]
    for frame in range(121):
        for fruit in range(12):
            assert base_fruit[frame, fruit]['radius_m'] == heavy_fruit[frame, fruit]['radius_m']
    frames = []
    paths = []
    for frame in range(0, 121, 10):
        row = {'frame': frame, 'time_s': frame / 120}
        positions = {}
        for name, prefix, fruit_states_by_frame in (
            ('original', BASE, base_fruit), ('triple', HEAVY, heavy_fruit)):
            obj = pathlib.Path(str(prefix) + f'-{frame}.obj')
            payload, mesh, fruits = geometry.read_snapshot(obj, faces)
            assert geometry.static_geometry(payload, require_finite=True) == 'finite_bench_and_room_floor'
            positions[name] = mesh
            paths.append(obj)
            row[name + '_obj_sha256'] = sha(obj)
            row[name + '_bottom_mean_z_m'] = sum(p[2] for p in mesh[1344:]) / 121
            row[name + '_released_fruit_count'] = sum(int(fruit_states_by_frame[frame, i]['released']) for i in range(12))
            for fruit in range(12):
                center, radius = fruits[fruit]
                state = fruit_states_by_frame[frame, fruit]
                assert all(abs(a - float(state[key])) < 2e-6 for a, key in zip(center, ('x_m', 'y_m', 'z_m')))
                assert abs(radius - float(state['radius_m'])) < 2e-6
        distances = [math.dist(a, b) for a, b in zip(positions['original'], positions['triple'])]
        row['cloth_rms_difference_m'] = math.sqrt(sum(d*d for d in distances) / len(distances))
        row['cloth_max_difference_m'] = max(distances)
        frames.append(row)
    framing = HERE / 'quick-record/framing-list.txt'
    framing.write_text(''.join(str(path) + '\n' for path in paths))
    output = HERE / 'quick-record/frames'
    output.mkdir(exist_ok=True)
    renderer = HERE / 'render-cloth-bag-focused'
    composer = HERE / 'compose-comparison'
    for index, row in enumerate(frames):
        pngs = []
        for name, prefix in (('original', BASE), ('triple', HEAVY)):
            png = output / f'{name}-{index:03}.png'
            subprocess.run([str(renderer), str(prefix) + f'-{row["frame"]}.obj',
                            str(png), 'trajectory', '--framing-list', str(framing)], check=True)
            pngs.append(png)
        combined = output / f'comparison-{index:03}.png'
        subprocess.run([str(composer), str(pngs[0]), str(pngs[1]),
                        str(combined), str(row['time_s'])], check=True)
    poster.write_bytes((output / 'comparison-012.png').read_bytes())
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-framerate', '3',
                    '-i', str(output / 'comparison-%03d.png'), '-c:v', 'libx264',
                    '-crf', '18', '-pix_fmt', 'yuv420p', '-r', '24',
                    '-movflags', '+faststart', str(video)], check=True)
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error',
        '-select_streams', 'v:0', '-show_streams', '-show_format', '-of', 'json',
        str(video)], text=True))
    stream = probe['streams'][0]
    assert stream['codec_name'] == 'h264' and stream['width'] == 1920 and stream['height'] == 860
    result = {
        'schema': 'numi.fruit-mass.available-first-replay-video.v1',
        'status': 'CROSS_HOST_FIRST_REPLAY_DIAGNOSTIC',
        'scope': 'First 120 frames from original-mass native Apple Metal run on MacBook Air and triple-mass native run on Mac mini. Different host and binary; not a controlled same-host comparison, exact two-replay result, or full pickup/landing qualification.',
        'change': 'Triple fruit mass and rotational inertia through inverse-mass scale 3; fruit radii, initial geometry, finite bench, bag and prescribed grip settings unchanged.',
        'original_host': 'MacBook Air', 'triple_host': 'Mac mini',
        'original_source_revision': '4bc9e94ee5e2268cc2197e02721006a336b26966',
        'triple_source_revision': '27d977a',
        'triple_source_file_sha256': 'f0757ce086ca8c5fbc64c426ecb7f81c3219f8f6e16b87ab4e89abea06346de1',
        'first_obj_sha256': sha(first_obj[0]),
        'original_csv_sha256': sha(pathlib.Path(str(BASE) + '-r1-fruits.csv')),
        'triple_csv_sha256': sha(pathlib.Path(str(HEAVY) + '-r1-fruits.csv')),
        'frames': frames,
        'largest_cloth_difference_m': max(row['cloth_max_difference_m'] for row in frames),
        'video_sha256': sha(video), 'poster_sha256': sha(poster),
        'renderer_source_sha256': sha(HERE / 'render_cloth_obj_bag.swift'),
        'composer_source_sha256': sha(HERE / 'compose_comparison.swift'),
        'pipeline_source_sha256': sha(pathlib.Path(__file__)),
        'video_stream': stream,
        'unmeasured': ['same-host matched control', 'second exact replay', 'independent contact audit of both clips', 'full pickup and landing', 'Franka gripper/arm dynamics', 'material calibration', 'energy and work closure'],
    }
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'video': str(video), 'status': result['status'],
                      'largest_cloth_difference_m': result['largest_cloth_difference_m']}))

if __name__ == '__main__':
    main()
