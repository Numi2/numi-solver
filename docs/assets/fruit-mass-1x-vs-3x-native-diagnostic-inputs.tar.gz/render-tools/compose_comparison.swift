import AppKit
import Foundation

guard CommandLine.arguments.count == 5 else {
    fputs("usage: compose_comparison LEFT.png RIGHT.png OUTPUT.png TIME_SECONDS\n", stderr)
    exit(2)
}
let leftURL = URL(fileURLWithPath: CommandLine.arguments[1])
let rightURL = URL(fileURLWithPath: CommandLine.arguments[2])
let outputURL = URL(fileURLWithPath: CommandLine.arguments[3])
guard let seconds = Double(CommandLine.arguments[4]), seconds.isFinite,
      let left = NSImage(contentsOf: leftURL),
      let right = NSImage(contentsOf: rightURL),
      let bitmap = NSBitmapImageRep(
          bitmapDataPlanes: nil,
          pixelsWide: 1920,
          pixelsHigh: 860,
          bitsPerSample: 8,
          samplesPerPixel: 4,
          hasAlpha: true,
          isPlanar: false,
          colorSpaceName: .deviceRGB,
          bytesPerRow: 0,
          bitsPerPixel: 0
      ), let graphics = NSGraphicsContext(bitmapImageRep: bitmap) else {
    fputs("invalid input image, time, or output bitmap\n", stderr)
    exit(1)
}
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = graphics
graphics.imageInterpolation = .high
NSColor(calibratedRed: 0.10, green: 0.14, blue: 0.17, alpha: 1).setFill()
NSRect(x: 0, y: 0, width: 1920, height: 860).fill()
left.draw(in: NSRect(x: 0, y: 0, width: 960, height: 800))
right.draw(in: NSRect(x: 960, y: 0, width: 960, height: 800))
let font = NSFont.systemFont(ofSize: 29, weight: .semibold)
let secondaryFont = NSFont.systemFont(ofSize: 21, weight: .medium)
let white: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: NSColor.white]
let light: [NSAttributedString.Key: Any] = [.font: secondaryFont,
                                           .foregroundColor: NSColor(calibratedWhite: 0.78, alpha: 1)]
("Original fruit mass" as NSString).draw(at: NSPoint(x: 28, y: 815), withAttributes: white)
("3× fruit mass · same size, bag, grip" as NSString).draw(at: NSPoint(x: 988, y: 815), withAttributes: white)
(String(format: "t = %.3f s  ·  Apple Metal simulation", seconds) as NSString)
    .draw(at: NSPoint(x: 530, y: 817), withAttributes: light)
NSGraphicsContext.restoreGraphicsState()
guard let data = bitmap.representation(using: .png, properties: [:]) else {
    fputs("could not encode comparison PNG\n", stderr)
    exit(1)
}
try data.write(to: outputURL, options: .atomic)
